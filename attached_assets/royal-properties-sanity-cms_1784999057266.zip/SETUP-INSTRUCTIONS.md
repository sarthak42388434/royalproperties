# Royal Properties — Sanity CMS Setup Instructions

This guide walks through the complete setup: creating a Sanity account,
connecting the website, inviting your client, and deploying to Vercel.

---

## Architecture Overview

```
Sanity Studio (Admin Dashboard)  ──→  Sanity Hosted Database
                                              │
                               Sanity CDN API (free, public read)
                                              │
                         royal-properties-cms.html  (your website on Vercel)
```

No backend server is required. The website fetches property data directly
from Sanity's CDN using a simple `fetch()` call.

---

## STEP 1 — Create a Sanity Account & Project

1. Go to **https://sanity.io** and sign up (free).
2. Once logged in, click **"New project"**.
3. Choose **"Blank project"** (or any template — schema will be overwritten).
4. Set the project name: `Royal Properties`
5. Choose dataset name: `production` (default, keep this)
6. Note your **Project ID** — you'll see it in the URL and project dashboard.
   It looks like: `abc12def`

---

## STEP 2 — Configure CORS (Allow your website to read data)

1. Go to: **https://sanity.io/manage** → your project → **API** → **CORS Origins**
2. Click **"Add CORS Origin"**
3. Add:
   - `http://localhost` (for local testing)
   - `https://your-vercel-domain.vercel.app` (your deployed website URL)
   - `https://your-custom-domain.com` (if you have one)
4. Leave **"Allow credentials"** unchecked (not needed for public content).

---

## STEP 3 — Deploy the Sanity Studio (Admin Dashboard)

The `sanity-studio/` folder is the admin dashboard where your client manages
properties. Deploy it to Vercel as a **separate project**.

### Option A — Deploy to Vercel (Recommended)

1. Push the `sanity-studio/` folder to a GitHub repository
   (or create a new repo just for it).
2. Go to **https://vercel.com** → New Project → Import your repo.
3. Add Environment Variables in Vercel:
   ```
   SANITY_STUDIO_PROJECT_ID = abc12def   ← your project ID
   SANITY_STUDIO_DATASET    = production
   ```
4. Deploy. Your Studio will be live at:
   `https://royal-properties-studio.vercel.app`

### Option B — Use Sanity's Free Managed Hosting

Inside the `sanity-studio/` folder, run:
```bash
npm install
npx sanity deploy
```
Choose a hostname like `royal-properties-admin`.
Studio is then live at: `https://royal-properties-admin.sanity.studio`

> **Tip:** Option B is simpler — no extra Vercel project needed for the studio.

---

## STEP 4 — Connect the Website to Sanity

Open **`royal-properties-cms.html`** in a text editor and find this block
near line 860:

```javascript
const SANITY_CONFIG = {
  projectId: 'YOUR_PROJECT_ID',   // ← replace this
  dataset:   'production',
  apiVersion:'2024-01-01',
  useCdn:    true,
};
```

Replace `YOUR_PROJECT_ID` with your actual project ID (e.g. `abc12def`).
Save the file.

---

## STEP 5 — Add Sample Properties in Sanity Studio

1. Open your Studio URL.
2. Click **"All Properties"** in the left sidebar.
3. Click **"+ New"** to add a property.
4. Fill in:
   - Property Title, Description, Price
   - Location, City/Area (used for filters)
   - Property Type, Purpose, Status
   - Bedrooms, Bathrooms, Area
   - Upload at least one image
   - Set **"Published"** to ON
5. Click **Publish** (top right of each document).

> Properties only appear on the website after you click **Publish**.
> Drafts are invisible to the public.

---

## STEP 6 — Deploy the Website to Vercel

1. Push `royal-properties-cms.html` to a GitHub repo.
2. Go to **https://vercel.com** → New Project → Import that repo.
3. **Framework Preset:** Other (Static HTML)
4. **Build Command:** (leave blank)
5. **Output Directory:** `.` (root)
6. Deploy. Your site is live at `https://your-site.vercel.app`.

> No environment variables are needed for the website itself — the
> Sanity Project ID is hardcoded in the HTML file.

---

## STEP 7 — Invite Your Client to the Dashboard

1. Go to **https://sanity.io/manage** → your project → **Members**
2. Click **"Invite members"**
3. Enter your client's email address
4. Set role:
   - **Editor** — can add, edit, publish properties (recommended for clients)
   - **Administrator** — full access including billing
5. Your client gets an email with a link to log in.

They manage all properties at the Studio URL you deployed in Step 3.

---

## How the Filters Work with CMS Data

The website uses a single `applyFilters()` function that reads from the
in-memory `properties` array. When Sanity data loads, it populates this
array and calls `applyFilters()` automatically.

**All filters continue to work identically:**
- Search bar (title, location, keywords)
- Filter by location / city
- Filter by property type
- Filter by purpose
- Filter by price range
- Filter by bedrooms
- Sort (newest, price low→high, price high→low)

The GROQ query in `royal-properties-cms.html` includes a `published == true`
filter, so unpublishing a property in Sanity immediately hides it on the website
(within Sanity's CDN cache time of ~60 seconds).

---

## Adding More Fields in the Future

1. Add the field to `sanity-studio/schemas/property.js`
2. Add it to the GROQ query in `royal-properties-cms.html`
3. Map it inside the `normaliseProperty()` function in the same file

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Website shows "0 properties found" | Check Project ID in HTML, check CORS settings |
| Images not loading | Sanity image URLs include `?w=800&auto=format` — ensure the project ID is correct |
| Studio won't load | Check `SANITY_STUDIO_PROJECT_ID` env var in Vercel |
| Client can't log in | Invite them via sanity.io/manage → Members |
| Filters not working | Ensure properties have `city`, `propertyType`, `purpose` fields filled in Sanity |

---

## File Reference

```
royal-properties-cms.html      ← Your website (deploy this to Vercel)
sanity-studio/
  ├── sanity.config.js         ← Studio configuration
  ├── schemas/
  │   ├── index.js             ← Schema barrel export
  │   └── property.js          ← All property fields definition
  ├── package.json             ← npm dependencies
  ├── .env.example             ← Copy to .env and fill in credentials
  ├── vercel.json              ← Vercel deployment config for Studio
  └── .gitignore
SETUP-INSTRUCTIONS.md          ← This file
```
