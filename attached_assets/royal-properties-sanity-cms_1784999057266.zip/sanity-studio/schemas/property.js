import {defineField, defineType} from 'sanity'

export default defineType({
  name: 'property',
  title: 'Property',
  type: 'document',

  fields: [
    defineField({
      name: 'propertyId',
      title: 'Property ID',
      type: 'string',
      description: 'Unique ID for this listing (e.g. RP-001)',
    }),
    defineField({
      name: 'title',
      title: 'Property Title',
      type: 'string',
      validation: (Rule) => Rule.required().min(3).max(120),
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      rows: 5,
    }),
    defineField({
      name: 'price',
      title: 'Price (Display Label)',
      type: 'string',
      description: 'Shown on card, e.g. "₹85 Lakhs" or "Price on Request"',
    }),
    defineField({
      name: 'priceValue',
      title: 'Price Value (Lakhs, numeric)',
      type: 'number',
      description: 'Used for sorting and filtering. Enter 0 if price is on request.',
    }),
    defineField({
      name: 'location',
      title: 'Full Location',
      type: 'string',
      description: 'e.g. Kakadeo, Naveen Nagar, Kanpur',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'city',
      title: 'City / Area (for filter)',
      type: 'string',
      options: {
        list: [
          {title: 'Kakadeo', value: 'Kakadeo'},
          {title: 'Pandu Nagar', value: 'Pandu Nagar'},
          {title: 'Naveen Nagar', value: 'Naveen Nagar'},
          {title: 'Govind Nagar', value: 'Govind Nagar'},
          {title: 'Kidwai Nagar', value: 'Kidwai Nagar'},
          {title: 'Shyam Nagar', value: 'Shyam Nagar'},
          {title: 'Armapur', value: 'Armapur'},
          {title: 'Kanpur (Other)', value: 'Kanpur'},
        ],
        layout: 'radio',
      },
    }),
    defineField({
      name: 'propertyType',
      title: 'Property Type',
      type: 'string',
      options: {
        list: [
          {title: 'Apartment', value: 'Apartment'},
          {title: 'Villa', value: 'Villa'},
          {title: 'Plot / Land', value: 'Plot'},
          {title: 'Commercial', value: 'Commercial'},
          {title: 'Office', value: 'Office'},
          {title: 'Farm House', value: 'Farm House'},
        ],
        layout: 'radio',
      },
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'purpose',
      title: 'Purpose',
      type: 'string',
      options: {
        list: [
          {title: 'For Sale', value: 'For Sale'},
          {title: 'For Rent', value: 'For Rent'},
          {title: 'Investment', value: 'Investment'},
          {title: 'Residential', value: 'Residential'},
          {title: 'Commercial', value: 'Commercial'},
        ],
        layout: 'radio',
      },
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'beds',
      title: 'Bedrooms',
      type: 'number',
      description: 'Leave blank for plots/commercial',
    }),
    defineField({
      name: 'baths',
      title: 'Bathrooms',
      type: 'number',
    }),
    defineField({
      name: 'area',
      title: 'Area / Size',
      type: 'string',
      description: 'e.g. 1200 sq.ft or 200 sq.yd',
    }),
    defineField({
      name: 'badge',
      title: 'Badge Label',
      type: 'string',
      description: 'Short label shown on card image, e.g. "For Sale", "Featured", "New"',
    }),
    defineField({
      name: 'featured',
      title: 'Featured Property',
      type: 'boolean',
      description: 'Mark to highlight this property as featured',
      initialValue: false,
    }),
    defineField({
      name: 'published',
      title: 'Published (visible on website)',
      type: 'boolean',
      description: 'Uncheck to hide this property from the website without deleting it',
      initialValue: true,
    }),
    defineField({
      name: 'status',
      title: 'Status',
      type: 'string',
      options: {
        list: [
          {title: 'Available', value: 'Available'},
          {title: 'Sold', value: 'Sold'},
          {title: 'Rented', value: 'Rented'},
        ],
        layout: 'radio',
      },
      initialValue: 'Available',
      validation: (Rule) => Rule.required(),
    }),
    defineField({
      name: 'images',
      title: 'Property Images',
      type: 'array',
      of: [
        {
          type: 'image',
          options: {hotspot: true},
          fields: [
            {
              name: 'alt',
              type: 'string',
              title: 'Alt Text',
              description: 'Describe the image for accessibility',
            },
          ],
        },
      ],
      description: 'Upload multiple images. First image is used as the card thumbnail.',
      validation: (Rule) => Rule.min(1).error('At least one image is required'),
    }),
    defineField({
      name: 'amenities',
      title: 'Amenities',
      type: 'array',
      of: [{type: 'string'}],
      options: {
        layout: 'tags',
      },
      description: 'e.g. Parking, Lift, 24/7 Security, Gym, Swimming Pool',
    }),
    defineField({
      name: 'nearby',
      title: 'Nearby Facilities',
      type: 'array',
      of: [{type: 'string'}],
      options: {layout: 'tags'},
      description: 'e.g. 2 km from City Mall, 500m from Metro Station',
    }),
    defineField({
      name: 'advantages',
      title: 'Location Advantages',
      type: 'array',
      of: [{type: 'string'}],
      options: {layout: 'tags'},
    }),
    defineField({
      name: 'highlights',
      title: 'Investment Highlights',
      type: 'array',
      of: [{type: 'string'}],
      options: {layout: 'tags'},
    }),
    defineField({
      name: 'contactNumber',
      title: 'Contact Number',
      type: 'string',
      description: 'Override contact number for this property (optional)',
    }),
  ],

  orderings: [
    {
      title: 'Newest First',
      name: 'newest',
      by: [{field: '_createdAt', direction: 'desc'}],
    },
    {
      title: 'Price: Low to High',
      name: 'priceLow',
      by: [{field: 'priceValue', direction: 'asc'}],
    },
    {
      title: 'Price: High to Low',
      name: 'priceHigh',
      by: [{field: 'priceValue', direction: 'desc'}],
    },
  ],

  preview: {
    select: {
      title: 'title',
      location: 'location',
      price: 'price',
      published: 'published',
      status: 'status',
      media: 'images.0',
    },
    prepare({title, location, price, published, status, media}) {
      const statusEmoji = published === false ? '🔴 Hidden' : status === 'Sold' ? '✅ Sold' : status === 'Rented' ? '🔵 Rented' : '🟢 Available'
      return {
        title: title || 'Untitled Property',
        subtitle: `${location || ''} · ${price || 'Price on Request'} · ${statusEmoji}`,
        media,
      }
    },
  },
})
