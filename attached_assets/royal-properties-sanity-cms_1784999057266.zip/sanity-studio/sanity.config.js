import {defineConfig} from 'sanity'
import {structureTool} from 'sanity/structure'
import {visionTool} from '@sanity/vision'
import {schemaTypes} from './schemas'

export default defineConfig({
  name: 'royal-properties',
  title: 'Royal Properties Admin',

  projectId: process.env.SANITY_STUDIO_PROJECT_ID,
  dataset: process.env.SANITY_STUDIO_DATASET || 'production',

  plugins: [
    structureTool({
      structure: (S) =>
        S.list()
          .title('Royal Properties')
          .items([
            S.listItem()
              .title('All Properties')
              .schemaType('property')
              .child(S.documentTypeList('property').title('All Properties')),
            S.divider(),
            S.listItem()
              .title('Featured Properties')
              .schemaType('property')
              .child(
                S.documentList()
                  .title('Featured Properties')
                  .filter('_type == "property" && featured == true')
              ),
            S.listItem()
              .title('For Sale')
              .schemaType('property')
              .child(
                S.documentList()
                  .title('For Sale')
                  .filter('_type == "property" && purpose == "For Sale"')
              ),
            S.listItem()
              .title('For Rent')
              .schemaType('property')
              .child(
                S.documentList()
                  .title('For Rent')
                  .filter('_type == "property" && purpose == "For Rent"')
              ),
            S.listItem()
              .title('Investment')
              .schemaType('property')
              .child(
                S.documentList()
                  .title('Investment')
                  .filter('_type == "property" && purpose == "Investment"')
              ),
          ]),
    }),
    visionTool(),
  ],

  schema: {
    types: schemaTypes,
  },
})
